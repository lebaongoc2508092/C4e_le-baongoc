const listStudents = [
  { id: 1, name: "Hoàng", age: 20, className: "abc" },
  { id: 2, name: "Nam", age: 21, className: "abc" },
  { id: 3, name: "Dũng", age: 22, className: "abc" },
];

function renderHtml(arr) {
  let table = document.querySelector("#list-student tbody");
  let strHTML = "";
  for (let i = 0; i < arr.length; i++) {
    strHTML += `<tr><td>${arr[i].id}</td><td>${arr[i].name}</td><td>${arr[i].age}</td><td>${arr[i].className}</td><td>
    
    <button onclick="deleteItem(${arr[i].id})">Xóa</button>

    <button onclick="editItem(${arr[i].id})">Sửa</button></td></tr>`;
  }

  table.innerHTML = strHTML;
}
let data = [];

function start() {
  renderHtml(listStudents);
}

function addNew() {
  var ip = document.querySelectorAll("input");
  let student = {
    id: listStudents.length + 1,
    name: ip[0].value,
    age: ip[1].value,
    className: ip[2].value,
  };

  listStudents.push(student);

  renderHtml(listStudents);
  ip[0].value = ip[1].value = ip[2].value = "";
}

document.getElementById("btn-add").onclick = addNew;

function deleteItem(id) {
  let index = listStudents.findIndex(function (item) {
    return item.id === id;
  });
  listStudents.splice(index, 1);
  // console.log(index);
  renderHtml(listStudents);
}

var ip = document.querySelectorAll("input");
let idEdit = 0;
function editItem(id) {
  let index = listStudents.findIndex();
  idEdit = index;
  ip[0].value = listStudents[index].name;
  ip[1].value = listStudents[index].age;
  ip[2].value = listStudents[index].className;
}

start();

document.getElementById("btn-edit").onclick = function () {
  listStudents[idEdit].name = ip[0].value;
  listStudents[idEdit].age = ip[1].value;
  listStudents[idEdit].className = ip[2].value;
  renderHtml(listStudents);
};

document.getElementById("btn-search").onclick = function () {
  let ipSearch = document.getElementById("search");
  function seach(item) {
    return (item.name = ipSearch.value);
  }
  var student = listStudents.find(seach);
  let newSearch = [];
  newSearch.push(student);
  renderHtml(newSearch);
  ipSearch.value = "";
};

document.getElementById("rd").onclick = function () {
  let ketqua = document.getElementById("ketqua");
  var kq = Math.floor(Math.random() * 12);
  ketqua.innerHTML = kq;
};

// sync asyn
// - callback function
// promise
// API

//prototype
// lập trình hướng đối tượng
// Hướng sự kiện

function renderHTML2() {
  var strHTML = listStudents.map(function (item) {
    return `<p>${item.name}</p>`;
  });
  let ketqua = document.getElementById("ketqua");
  ketqua.innerHTML = strHTML.join("");
}

// sort
//reduce

//forEach()

renderHTML2();
